package com.quitespace.hellosharedprefs;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private int mCount = 0;
    private int mColor;

    private TextView mShowCountTextView;
    private LinearLayout mMainLayout;

    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.hellosharedprefs";

    private final String COUNT_KEY = "count";
    private final String COLOR_KEY = "color";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowCountTextView = findViewById(R.id.show_count);
        mMainLayout = findViewById(R.id.main_layout);

        mColor = Color.GRAY;

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        // Restore from SharedPreferences
        mCount = mPreferences.getInt(COUNT_KEY, 0);
        mColor = mPreferences.getInt(COLOR_KEY, Color.GRAY);

        mShowCountTextView.setText(String.valueOf(mCount));
        mMainLayout.setBackgroundColor(mColor);

        findViewById(R.id.button_count).setOnClickListener(v -> countUp());
        findViewById(R.id.button_black).setOnClickListener(v -> changeBackground(Color.BLACK));
        findViewById(R.id.button_red).setOnClickListener(v -> changeBackground(Color.RED));
        findViewById(R.id.button_green).setOnClickListener(v -> changeBackground(Color.GREEN));
        findViewById(R.id.button_blue).setOnClickListener(v -> changeBackground(Color.BLUE));
        findViewById(R.id.button_reset).setOnClickListener(v -> reset());
    }

    private void countUp() {
        mCount++;
        mShowCountTextView.setText(String.valueOf(mCount));
    }

    private void changeBackground(int color) {
        mColor = color;
        mMainLayout.setBackgroundColor(mColor);
    }

    private void reset() {
        mCount = 0;
        mColor = Color.GRAY;
        mShowCountTextView.setText(String.valueOf(mCount));
        mMainLayout.setBackgroundColor(mColor);

        SharedPreferences.Editor editor = mPreferences.edit();
        editor.clear();
        editor.apply();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putInt(COUNT_KEY, mCount);
        editor.putInt(COLOR_KEY, mColor);
        editor.apply();
    }
}
